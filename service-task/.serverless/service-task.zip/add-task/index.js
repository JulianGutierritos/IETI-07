var tasks = [];

module.exports.add = (event, context, callback) => {
    //context.log('Adding a task to the planner');
    var task = JSON.parse(event.body);
	tasks.push(task);
	task["id"] = tasks.length + 4;
    const responseMessage = { response: "Task created!", task};
    const response = {
		statusCode: 201,
		body: JSON.stringify({
			responseMessage
		})
	};
	callback(null, response); 
}
